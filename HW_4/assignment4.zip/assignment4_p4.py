# Exercise 7-2

# a friend of mine told me that eval is very dangerous
def eval_loop():
    inp = input('enter value')
    ev = 0
    if inp == 'done':  # special case for if done entered first
        return "nothing was entered"
    while inp != 'done':  # while the user wants to continue to do this
        ev = eval(inp)  # takes user function and solves
        print(ev)
        inp = input('enter value')  # prompts to redo expression
    print(ev)  # after loop is broken, returns last values


eval_loop()
